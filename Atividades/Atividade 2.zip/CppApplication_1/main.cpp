#include <time.h>
#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    float altura = 0;
    srand(time(NULL));
    
    
    float maior = 0;
    int contador = 0;
    float menor = 231;
    float porcentagem;
    
    for (int i = 0; i < 1000; i++){
        int alturaAtual = rand()%(230 +1 -150) + 150;
        altura = altura + alturaAtual;
        if (maior < alturaAtual){
            maior = alturaAtual;
        }
        if (menor > alturaAtual){
            menor = alturaAtual;
        }
        if (alturaAtual > 200){
            contador = contador + 1;
        }
    }
    
    altura = altura / 100;
    porcentagem = contador * 100 / 1000;
    
    float media = altura / 1000;
    
    cout << "A média é " << media << endl;
    
    cout << "A maior altura é " << maior/100 << endl;
    
    cout << "A menor Altura é "<< menor/100 << endl;
    
    cout << "A porcentagem é " << porcentagem << endl;
    
    return 0;
}

