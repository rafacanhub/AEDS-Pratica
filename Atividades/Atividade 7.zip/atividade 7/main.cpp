/*
 * Descrição do Projeto:
 * Este projeto tem como objetivo resolver diferentes problemas relacionados à manipulação de dados,
 * usando vetores, estruturas e manipulação de arquivos. Cada questão envolve a leitura, processamento e
 * apresentação de dados de forma específica.
 *
 * Autor: [Rafael Candido da Cruz]
 */




#include <iostream>


using namespace std;

const int LINHAS = 3;
const int COLUNAS = 3;

void transpor(int mat[LINHAS][COLUNAS], int resultado[COLUNAS][LINHAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            resultado[j][i] = mat[i][j];
        }
    }
}

void somar(int mat1[LINHAS][COLUNAS], int mat2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            resultado[i][j] = mat1[i][j] + mat2[i][j];
        }
    }
}

void multiplicar(int mat1[LINHAS][COLUNAS], int mat2[LINHAS][COLUNAS], int resultado[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            resultado[i][j] = 0;
            for (int k = 0; k < COLUNAS; ++k) {
                resultado[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }
}

double media(int mat[LINHAS][COLUNAS]) {
    int soma = 0;
    int totalElementos = LINHAS * COLUNAS;
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            soma += mat[i][j];
        }
    }
    return static_cast<double>(soma) / totalElementos;
}

void imprimirMatriz(int mat[LINHAS][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int matriz1[LINHAS][COLUNAS] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    int matriz2[LINHAS][COLUNAS] = {
        {9, 8, 7},
        {6, 5, 4},
        {3, 2, 1}
    };

    int transposta[COLUNAS][LINHAS];
    int soma[LINHAS][COLUNAS];
    int produto[LINHAS][COLUNAS];

    transpor(matriz1, transposta);
    cout << "Transposta da primeira matriz:" << endl;
    for (int i = 0; i < COLUNAS; ++i) {
        for (int j = 0; j < LINHAS; ++j) {
            cout << transposta[i][j] << " ";
        }
        cout << endl;
    }

    somar(matriz1, matriz2, soma);
    cout << "Soma das duas matrizes:" << endl;
    imprimirMatriz(soma);

    multiplicar(matriz1, matriz2, produto);
    cout << "Produto das duas matrizes:" << endl;
    imprimirMatriz(produto);

    double avg = media(matriz1);
    cout << "Valor médio dos valores da primeira matriz: " << avg << endl;

    return 0;
}
