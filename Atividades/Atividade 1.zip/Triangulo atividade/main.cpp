
#include <cmath>

#include <cstdlib>

#include <stdio.h>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //
    int a, b, c;

    scanf("%d",&a);
    
    scanf ("%d",&b);

    scanf ("%d",&c);        
    
    
    if ( (a + b > c) && (b + c > a) && (a + c > b)){
        printf("É um triângulo ");
       
        if(a == b && b == c){
             printf("equilátero \n");
        }
        
        else if ( (a == b && a != c) || ( a == c && a != b) || (b == c && c != a)) {
            printf("isóceles \n");
        }
        
        else if ((a != b) && (b != c) && (a != c)) {
            printf("escaleno");
        
            if ( (pow(a,2) == pow(b,2) + pow(c,2)) || (pow (b,2) == pow (a,2) + pow(c,2)) || (pow(c,2) == pow(a,2) + pow(b,2)) ){
        
                printf(" E retângulo");
            }
            
        }
            
        
        
        
    }
    
    else {
        printf("Não é um triângulo");
    }

            
    return 0;
}

