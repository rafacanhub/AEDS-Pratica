#include <fstream>
#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char** argv) {
    ifstream arquivo("cenagrafica.txt");
    string nome;
    int valor, base, altura, raio;
    int volume;
    int area;
    float pi = 3.16;

    arquivo >> nome;
    cout << nome << endl;

    while (nome != "fim") {
        if (nome == "cubo") {
            arquivo >> valor;
            cout << valor << endl;
            volume = valor * valor * valor;
            cout << volume << endl;
        }

        arquivo >> nome;
        cout << nome << endl;

        if (nome == "triangulo") {
            arquivo >> base;
            cout << base << endl;
            arquivo >> altura;
            cout << altura << endl;
            area = base * altura / 2;
            cout << area << endl;
        }

        arquivo >> nome;
        cout << nome << endl;

        if (nome == "esfera") {
            arquivo >> raio;
            cout << raio << endl;
            area = 4 * pi * raio * raio;
            cout << area << endl;
        }

        if (nome != "fim") {
            arquivo >> nome;
            cout << nome << endl;
        }
    }

    return 0;
}
