#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <ctime>

//Descrição: Este projeto em C/C++ permite ao usuário realizar diversas operações em um vetor de 1000 posições contendo valores inteiros. O programa inicia inserindo valores aleatórios no vetor e, em seguida, apresenta um menu de operações disponíveis.
//As operações incluem buscar a primeira ocorrência de um valor no vetor, contar quantas vezes um valor específico ocorre, contar quantas vezes os valores estão dentro de um intervalo especificado, inverter os valores do vetor, excluir um valor informado pelo usuário (se existir), e retirar todos os valores repetidos. 
//O programa permite ao usuário repetir essas operações quantas vezes desejar, até optar por sair do programa.


//Autor: Rafael Cândido da Cruz

using namespace std;

#define tam 1000

int main() {
    int vetor[tam];
    srand(time(NULL));
    for (int i = 0; i < tam; i++) {
        vetor[i] = rand() % (1000 + 1 - 100) + 100;
    }

    int opcao;
    do {
        cout << "\nMenu de Operacoes:\n";
        cout << "1. Buscar primeira ocorrencia de um valor\n";
        cout << "2. Contar ocorrencias de um valor\n";
        cout << "3. Contar ocorrencias de valores em um intervalo\n";
        cout << "4. Inverter os valores do vetor\n";
        cout << "5. Excluir um valor do vetor\n";
        cout << "6. Retirar valores repetidos do vetor\n";
        cout << "7. Sair\n";
        cout << "Escolha uma opcao: ";
        cin >> opcao;

        switch (opcao) {
            case 1: {
                int valor;
                cout << "Digite o valor a ser buscado: ";
                cin >> valor;

                int i = 0;
                while (i < tam && vetor[i] != valor){
                    i++;
                }

                if (i != tam){
                    cout << "Primeira ocorrencia de " << valor << " encontrada na posicao " << i << endl;
                } else{
                    cout << "Valor nao encontrado no vetor." << endl;
                }
                break;
            }
            case 2: {
                int valor;
                cout << "Digite o valor a ser contado: ";
                cin >> valor;

                int ocorrencias = count(vetor, vetor + tam, valor);

                cout << "Quantidade de ocorrencias de " << valor << ": " << ocorrencias << endl;

                break;
            }
            case 3: {
                int inicio, fim;
                cout << "Digite o intervalo (inicio e fim): ";
                cin >> inicio >> fim;

                int contador = count_if(vetor, vetor + tam, [=](int x) { return x >= inicio && x <= fim; });

                cout << "Ocorrencias de valores no intervalo [" << inicio << ", " << fim << "]: " << contador << endl;
                break;
            }
            case 4: {
                reverse(vetor, vetor + tam);
                cout << "Vetor invertido com sucesso." << endl;
                break;
            }
            case 5: {
                int valor;
                cout << "Digite o valor a ser excluido: ";
                cin >> valor;
                

                cout << "Valor " << valor << " excluido do vetor.\n";
                break;
            }
            case 6: {
               
                cout << "Valores repetidos removidos do vetor.\n";
                break;
            }
            case 7:
                cout << "Encerrando o programa.\n";
                break;
            default:
                cout << "Opcao invalida. Por favor, escolha uma opcao valida.\n";
        }
    } while (opcao != 7);

    return 0;
}
