#include <iostream>
#include <fstream>
#include <string>

//Descrição: Este é um projeto em C++ que implementa uma agenda de amigos. Ele permite armazenar, buscar e excluir informações de amigos, como nome, celular, cidade e e-mail. 
//A aplicação utiliza conceitos básicos de C++ e armazena os dados em um arquivo de texto. 

//Autor: Rafael Candido da Cruz


const int MAX_AMIGOS = 100;

struct Amigo {
    std::string nome;
    std::string celular;
    std::string cidade;
    std::string email;
    bool valido;
};

int lerArquivo(Amigo agenda[]) {
    std::ifstream arquivo("agenda.txt");
    int totalAmigos = 0;

    if (arquivo.is_open()) {
        while (totalAmigos < MAX_AMIGOS && arquivo >> agenda[totalAmigos].nome >> agenda[totalAmigos].celular >> agenda[totalAmigos].cidade >> agenda[totalAmigos].email >> agenda[totalAmigos].valido) {
            totalAmigos++;
        }
        arquivo.close();
    }

    return totalAmigos;
}

void salvarArquivo(const Amigo agenda[], int totalAmigos) {
    std::ofstream arquivo("agenda.txt");

    if (arquivo.is_open()) {
        for (int i = 0; i < totalAmigos; ++i) {
            if (agenda[i].valido) {
                arquivo << agenda[i].nome << " " << agenda[i].celular << " " << agenda[i].cidade << " " << agenda[i].email << " " << agenda[i].valido << std::endl;
            }
        }
        arquivo.close();
    }
}

void buscarPorNome(const Amigo agenda[], int totalAmigos, const std::string& nome) {
    bool encontrado = false;
    for (int i = 0; i < totalAmigos; ++i) {
        if (agenda[i].nome == nome && agenda[i].valido) {
            encontrado = true;
            std::cout << "Nome: " << agenda[i].nome << std::endl;
            std::cout << "Celular: " << agenda[i].celular << std::endl;
            std::cout << "Cidade: " << agenda[i].cidade << std::endl;
            std::cout << "Email: " << agenda[i].email << std::endl;
            break;
        }
    }
    if (!encontrado) {
        std::cout << "Amigo não encontrado." << std::endl;
    }
}

void excluirAmigo(Amigo agenda[], int totalAmigos, const std::string& nome) {
    for (int i = 0; i < totalAmigos; ++i) {
        if (agenda[i].nome == nome) {
            agenda[i].valido = false;
            std::cout << "Amigo excluído com sucesso." << std::endl;
            return;
        }
    }
    std::cout << "Amigo não encontrado." << std::endl;
}

void inserirAmigo(Amigo agenda[], int& totalAmigos) {
    if (totalAmigos < MAX_AMIGOS) {
        std::cout << "Nome: ";
        std::cin >> agenda[totalAmigos].nome;
        std::cout << "Celular: ";
        std::cin >> agenda[totalAmigos].celular;
        std::cout << "Cidade: ";
        std::cin >> agenda[totalAmigos].cidade;
        std::cout << "Email: ";
        std::cin >> agenda[totalAmigos].email;
        agenda[totalAmigos].valido = true;
        totalAmigos++;
    } else {
        std::cout << "A agenda está cheia, não é possível adicionar mais amigos." << std::endl;
    }
}

int main() {
    Amigo agenda[MAX_AMIGOS];
    int totalAmigos = lerArquivo(agenda);

    int opcao;
    do {
        std::cout << "\nMenu de Operações:\n";
        std::cout << "1. Buscar por nome\n";
        std::cout << "2. Excluir amigo\n";
        std::cout << "3. Inserir amigo\n";
        std::cout << "4. Sair\n";
        std::cout << "Escolha uma opção: ";
        std::cin >> opcao;

        switch (opcao) {
            case 1: {
                std::string nome;
                std::cout << "Digite o nome do amigo: ";
                std::cin >> nome;
                buscarPorNome(agenda, totalAmigos, nome);
                break;
            }
            case 2: {
                std::string nome;
                std::cout << "Digite o nome do amigo a ser excluído: ";
                std::cin >> nome;
                excluirAmigo(agenda, totalAmigos, nome);
                break;
            }
            case 3:
                inserirAmigo(agenda, totalAmigos);
                break;
            case 4:
                std::cout << "Encerrando o programa." << std::endl;
                break;
            default:
                std::cout << "Opção inválida. Por favor, escolha uma opção válida." << std::endl;
        }
    } while (opcao != 4);

    salvarArquivo(agenda, totalAmigos);

    return 0;
}
