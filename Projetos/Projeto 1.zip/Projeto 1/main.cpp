#include <iostream>
#include <vector>
#include <string>
#include <cstring>

#define MAX_VEICULOS 100

struct Veiculo {
    char modelo[20], marca[20], tipo[20], combustivel[20], cambio[20], direcao[20], cor[20], placa[10];
    int ano, quilometragem, portas;
    float potencia, valor;
    bool valido;
};

void carregarDados(std::vector<Veiculo>& veiculos, const char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "r");
    if (!arquivo) {
        std::cerr << "Erro ao abrir o arquivo!\n";
        return;
    }

    Veiculo veiculo;
    while (fscanf(arquivo, "%s %s %s %d %d %f %s %s %s %s %d %s %f",
                  veiculo.modelo, veiculo.marca, veiculo.tipo, &veiculo.ano, &veiculo.quilometragem,
                  &veiculo.potencia, veiculo.combustivel, veiculo.cambio, veiculo.direcao, veiculo.cor,
                  &veiculo.portas, veiculo.placa, &veiculo.valor) == 13) {
        if (strcmp(veiculo.modelo, "FIM") == 0) break;

        veiculo.valido = true;
        veiculos.push_back(veiculo);
    }

    fclose(arquivo);
}

void salvarDados(const std::vector<Veiculo>& veiculos, const char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "w");
    if (!arquivo) {
        std::cerr << "Erro ao abrir o arquivo!\n";
        return;
    }

    for (const auto& veiculo : veiculos) {
        if (veiculo.valido) {
            fprintf(arquivo, "%s %s %s %d %d %.1f %s %s %s %s %d %s %.2f\n",
                    veiculo.modelo, veiculo.marca, veiculo.tipo, veiculo.ano, veiculo.quilometragem,
                    veiculo.potencia, veiculo.combustivel, veiculo.cambio, veiculo.direcao, veiculo.cor,
                    veiculo.portas, veiculo.placa, veiculo.valor);
        }
    }

    fclose(arquivo);
}

void incluirVeiculo(std::vector<Veiculo>& veiculos) {
    if (veiculos.size() >= MAX_VEICULOS) {
        std::cout << "A base de dados está cheia!\n";
        return;
    }

    Veiculo veiculo;
    std::cout << "Informe os dados do veículo:\n";
    std::cout << "Modelo: "; std::cin >> veiculo.modelo;
    std::cout << "Marca: "; std::cin >> veiculo.marca;
    std::cout << "Tipo: "; std::cin >> veiculo.tipo;
    std::cout << "Ano: "; std::cin >> veiculo.ano;
    std::cout << "Quilometragem: "; std::cin >> veiculo.quilometragem;
    std::cout << "Potência: "; std::cin >> veiculo.potencia;
    std::cout << "Combustível: "; std::cin >> veiculo.combustivel;
    std::cout << "Câmbio: "; std::cin >> veiculo.cambio;
    std::cout << "Direção: "; std::cin >> veiculo.direcao;
    std::cout << "Cor: "; std::cin >> veiculo.cor;
    std::cout << "Portas: "; std::cin >> veiculo.portas;
    std::cout << "Placa: "; std::cin >> veiculo.placa;
    std::cout << "Valor: "; std::cin >> veiculo.valor;

    veiculo.valido = true;
    veiculos.push_back(veiculo);
}

void excluirVeiculo(std::vector<Veiculo>& veiculos, const char* placa) {
    for (auto& veiculo : veiculos) {
        if (strcmp(veiculo.placa, placa) == 0 && veiculo.valido) {
            veiculo.valido = false;
            std::cout << "Veículo excluído.\n";
            return;
        }
    }
    std::cout << "Veículo não encontrado.\n";
}

void buscarVeiculoPorPlaca(const std::vector<Veiculo>& veiculos, const char* placa) {
    for (const auto& veiculo : veiculos) {
        if (strcmp(veiculo.placa, placa) == 0 && veiculo.valido) {
            std::cout << "Veículo encontrado: " << veiculo.modelo << " " << veiculo.marca << " " << veiculo.ano << "\n";
            return;
        }
    }
    std::cout << "Veículo não encontrado.\n";
}

void buscarVeiculoPorTipo(const std::vector<Veiculo>& veiculos, const char* tipo) {
    for (const auto& veiculo : veiculos) {
        if (strcmp(veiculo.tipo, tipo) == 0 && veiculo.valido) {
            std::cout << veiculo.modelo << " " << veiculo.marca << " " << veiculo.ano << " " << veiculo.placa << "\n";
        }
    }
}

void buscarVeiculoPorCambio(const std::vector<Veiculo>& veiculos, const char* cambio) {
    for (const auto& veiculo : veiculos) {
        if (strcmp(veiculo.cambio, cambio) == 0 && veiculo.valido) {
            std::cout << veiculo.modelo << " " << veiculo.marca << " " << veiculo.ano << " " << veiculo.placa << "\n";
        }
    }
}

void buscarVeiculoPorFaixaDeValores(const std::vector<Veiculo>& veiculos, float minValor, float maxValor) {
    for (const auto& veiculo : veiculos) {
        if (veiculo.valor >= minValor && veiculo.valor <= maxValor && veiculo.valido) {
            std::cout << veiculo.modelo << " " << veiculo.marca << " " << veiculo.ano << " " << veiculo.placa << " R$ " << veiculo.valor << "\n";
        }
    }
}

void relatorio(const std::vector<Veiculo>& veiculos) {
   
}

void menu(std::vector<Veiculo>& veiculos) {
    int opcao;
    do {
        std::cout << "Menu de Opções:\n";
        std::cout << "1. Incluir veículo\n";
        std::cout << "2. Excluir veículo\n";
        std::cout << "3. Buscar veículo por placa\n";
        std::cout << "4. Buscar veículo por tipo\n";
        std::cout << "5. Buscar veículo por câmbio\n";
        std::cout << "6. Buscar veículo por faixa de valores\n";
        std::cout << "7. Relatório\n";
        std::cout << "8. Sair\n";
        std::cout << "Opção: ";
        std::cin >> opcao;

        switch (opcao) {
            case 1:
                incluirVeiculo(veiculos);
                break;
            case 2: {
                char placa[10];
                std::cout << "Informe a placa: ";
                std::cin >> placa;
                excluirVeiculo(veiculos, placa);
                break;
            }
            case 3: {
                char placa[10];
                std::cout << "Informe a placa: ";
                std::cin >> placa;
                buscarVeiculoPorPlaca(veiculos, placa);
                break;
            }
            case 4: {
                char tipo[20];
                std::cout << "Informe o tipo: ";
                std::cin >> tipo;
                buscarVeiculoPorTipo(veiculos, tipo);
                break;
            }
            case 5: {
                char cambio[20];
                std::cout << "Informe o câmbio: ";
                std::cin >> cambio;
                buscarVeiculoPorCambio(veiculos, cambio);
                break;
            }
            case 6: {
                float minValor, maxValor;
                std::cout << "Informe o valor mínimo: ";
                std::cin >> minValor;
                std::cout << "Informe o valor máximo: ";
                std::cin >> maxValor;
                buscarVeiculoPorFaixaDeValores(veiculos, minValor, maxValor);
                break;
            }
            case 7:
                relatorio(veiculos);
                break;
            case 8:
                std::cout << "Saindo...\n";
                break;
            default:
                std::cout << "Opção inválida!\n";
                break;
        }
    } while (opcao != 8);
}

int main() {
    std::vector<Veiculo> veiculos;
    const char* nomeArquivo = "BD_veiculos.txt";

    carregarDados(veiculos, nomeArquivo);
    menu(veiculos);
    salvarDados(veiculos, nomeArquivo);

    return 0;
}
